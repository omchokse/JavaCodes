import java.util.*;

public class pattern_25 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int row = 1;
        int number = 1;
        int space = n - 1;
        int num = 1;
        while (row <= n) {
            int i = 1;
            while (i <= space) {
                System.out.print("  ");
                i++;
            }
            int j = 1;
            while (j <= num) {
                System.out.print(number + " ");
                j++;
            }
            space--;
            num += 2;
            number = 1;
            row++;
            System.out.println();
        }
    }
}
