import java.util.*;

public class patt01 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int row = 1;
        int space = 2 * n - 1;
        int nums = 1;
        int num = 5;
        while (row <= 2 * n) {
            int i = 1;
            while (i <= nums) {
                System.out.print(num + " ");
                if (i < nums) {
                    num--;
                }
                i++;
            }
            int j = 1;
            while (j <= space) {
                System.out.print("  ");
                j++;
            }
            int k = 1;
            while (k <= nums) {
                System.out.print(num + " ");
                if (k < nums) {
                    num++;
                }
                if (nums == k) {
                    k = 4;
                }
                k++;
            }
            if (row <= n) {
                nums++;
                space -= 2;
            } else {
                nums--;
                space += 2;
            }
            row++;
            num = 5;
            System.out.println();
        }
    }
}