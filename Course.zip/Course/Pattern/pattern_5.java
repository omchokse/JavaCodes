import java.util.*;

public class pattern_5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int row = 1;
        int star = n;
        int space = star - n;
        while (row <= n) {
            int i = 0;
            while (i < space) {
                System.out.print("  ");
                i++;
            }
            int j = 0;
            while (j < star) {
                System.out.print("* ");
                j++;
            }
            row++;
            space++;
            star--;
            System.out.println();
        }
    }
}
