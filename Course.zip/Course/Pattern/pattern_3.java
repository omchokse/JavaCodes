import java.util.*;

public class pattern_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int row = 1;
        int star = n;
        while (row <= n) {
            int i = star;
            while (i > 0) {
                System.out.print("* ");
                i--;
            }
            row++;
            star--;
            System.out.println();
        }
    }
}
