public class arrays_demo_2 {
    public static void main(String[] args) {
        int [] arr=new int[5];
        arr[0]=10;
        arr[1]=20;
        arr[2]=30;
        arr[3]=40;
        arr[4]=50;
        System.out.println(arr);
        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
        System.out.println(arr[3]);
        System.out.println(arr[4]);
        int [] other=arr; //other koi naya variable hai jo arr ko refer krra hai alag array nahi bani
        /*yahan ek hi array hai
        bas baat itni hai ki other point krra hai arr ki taraf
        */ 
        System.out.println(other);
        other[4]=4;
        System.out.println(arr[4]); // jaise other me change krne se arr me change hua
    }
}
//jab tak new ka use nahi krege tab tak naya array nahi banega