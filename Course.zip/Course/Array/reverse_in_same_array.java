public class reverse_in_same_array {
    static int j=0;
    public static void main(String[] args) {
        int []arr={1,2,7,6,8,4,9};
        j=arr.length-1;
        Reverse(arr);
        Display(arr);
    }
    public static void Reverse(int []arr){
        for(int i=0;i<=arr.length/2;i++){
            Swap(arr,i,j);
            j--;
        }
    }
    public static void Swap(int []arr,int i,int j){
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }
    public static void Display(int []arr){
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
