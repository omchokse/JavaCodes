import java.util.*;
public class array_rotation_custom {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        int []arr=new int[size];
        for(int x=0;x<size;x++){
            arr[x]=sc.nextInt();
        }
        int f=sc.nextInt();
        Rotate(arr, f);
        Display(arr);
        sc.close();
    }
    public static void Rotate(int []arr,int f){
        for(int j=f;j>0;j--){
        int n=arr.length-1;
        int temp=arr[n];
        for(int i=n;i>0;i--){
            arr[i]=arr[i-1];
        }
        arr[0]=temp;
    }
}
public static void Display(int []arr){
    for(int l=0;l<arr.length;l++){
        System.out.print(arr[l]+" ");
    }
}
}
