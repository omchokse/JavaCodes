public class array_swap_demo {
    public static void main(String[] args) {
        int[] arr={10,20,5,7,8};
        System.out.println(arr[0]+" "+arr[1]);
        Swap(arr,0, 1);
        System.out.println(arr[0]+" "+arr[1]);
        Display(arr);
    }
    public static void Swap(int[]arr,int i, int j){
        int temp=arr[i];
        arr[i]=arr[j];// ghar me ghuske change maarna:mtlb array ke andar ghuske change krna padega tab changes aayege
        arr[j]=temp;
    }
    public static void Display(int []arr){
        for(int i=0;i<arr.length;i++){    
        System.out.println(arr[i]); // we can see changes will be reflected in array
        }
    }
}
// heap me kiya hua change reflect hota hai
// stack me kiya hua change reflect nahi hota hai