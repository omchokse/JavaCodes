import java.util.*;
public class reverse_array_custom {
    static int j=0;
    static int i=0;
    public static void main(String[] args) {
        int []arr={1,2,7,6,8,4,9};
        Scanner sc=new Scanner(System.in);
        i=sc.nextInt();
        j=sc.nextInt();
        Reverse(arr);
        Display(arr);
        sc.close();
    }
    public static void Reverse(int []arr){
        for(;i<=arr.length/2;i++){
            Swap(arr,i,j);
            j--;
        }
    }
    public static void Swap(int []arr,int l,int n){
        int temp=arr[l];
        arr[l]=arr[n];
        arr[n]=temp;
    }
    public static void Display(int []arr){
        for(int m=0;m<arr.length;m++){
            System.out.print(arr[m]+" ");
        }
    }
}
