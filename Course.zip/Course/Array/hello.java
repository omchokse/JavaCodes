public class hello {
    public static void main(String[] args) {
        int []arr=null ;
        System.out.println(arr);
    }
}
