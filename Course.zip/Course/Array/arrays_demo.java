public class arrays_demo{
    public static void main(String[] args) {
        int [] arr=new int[5];
        System.out.println(arr[5]);
    }
}