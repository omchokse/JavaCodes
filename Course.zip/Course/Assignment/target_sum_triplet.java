import java.util.*;
public class target_sum_triplet {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int []arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        int t=sc.nextInt();
        Arrays.sort(arr);
        for(int j=0;j<n;j++){
            for(int k=j+1;k<n;k++){
                for(int l=k+1;l<n;l++){
                    if(arr[j]+arr[k]+arr[l]==t){
                        System.out.println(" "+arr[j]+", "+arr[k]+" and "+arr[l]);
                    }
                }
            }
        }
    }
}
