import java.util.*;

public class test {
    public static void main(String args[]){
        Scanner sc =new Scanner(System.in);
        int n=sc.nextInt();
        int m=sc.nextInt();
        LinkedList<Integer>l1=new LinkedList<>();
        LinkedList<Integer>l2=new LinkedList<>();
        Stack<Integer>st=new Stack<>();
        int rev=1;
        int sum1=0;
        for(int i=0;i<n;i++){
            l1.add(sc.nextInt());
            sum1=(sum1*rev)+l1.get(i);
            rev=10;
        }
        rev=1;
        int sum=0;
        for(int i=0;i<n;i++){
            l2.add(sc.nextInt());
            sum=(sum*rev)+l2.get(i);
            rev=10;
        }
       sum=sum+sum1;
       for(int i=sum;i>0;i=i/10){
        int r=i%10;
        st.push(r);
       }
       while(!st.isEmpty()){
        System.out.print(st.pop()+" ");
       }
    }
}