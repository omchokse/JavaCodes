public class salon {
    public static void main(String args[]) {
        double bill = 500;
        double tax = (5 / 100) * bill;
        double tax2 = (8 / 100) * bill;
        double nb = bill + tax + tax2;
        System.out.println(nb);
    }
}