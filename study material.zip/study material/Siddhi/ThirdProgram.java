public class ThirdProgram {
    public static void main(String args[]) {
        System.out.println("Name:" + "Siddhi chokse");
        System.out.println("Age:" + "13");
        System.out.println("Class:" + "8B");
        System.out.println("Roll no.:43");
    }
}
