public class SI {
    public static void main(String args[]) {
        int P = 1000;
        double R = 2.4;
        int T = 2;
        double simin = (P * R * T) / 100;
        System.out.println(simin);
    }
}