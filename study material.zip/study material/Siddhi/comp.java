public class comp {
    public static void main(String args[]) {
        int a = 4;
        int b = 6;
        if (a > b) {
            System.out.println("a is greater than b");
        } else if (a == b) {
            System.out.println("a is equal to b");
        } else {
            System.out.println("a is smaller than b");
        }
    }
}