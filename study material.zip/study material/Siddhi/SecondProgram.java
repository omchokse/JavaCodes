public class SecondProgram {
    public static void main(String args[]) {
        System.out.println("My name is siddhi chokse");
        System.out.println("I study in SFC");
        System.out.println("My school us very cool");
        System.out.println("We are full of attitude");
    }
}