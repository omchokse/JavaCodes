public class voting {
    public static void main(String[] args) {
        int age = 17;
        if (age > 18) {
            System.out.println("eligible to vote");
        } else if (age == 18) {
            System.out.println("jao voter id banwalo");
        } else {
            System.out.println("not eligible to vote");
        }
    }
}