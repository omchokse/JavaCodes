public class Siddhimart {
    public static void main(String[] args) {
        int bill = 400;
        int newbill = (((5 / 100) * bill) + bill);
        System.out.println(newbill);
    }
}
