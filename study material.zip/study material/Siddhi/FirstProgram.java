public class FirstProgram // First class
{
    public static void main(String args[]) {
        System.out.println("welcome siddhi chokse");
    }
}