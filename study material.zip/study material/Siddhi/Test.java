public class Test {
    public static void main(String args[]) {
        int num = -2;
        if (num >= 0) {
            System.out.println("Number is positive");
        } else {
            System.out.println("Number is negative");
        }
    }
}