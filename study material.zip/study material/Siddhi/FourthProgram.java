public class FourthProgram {
    public static void main(String[] args) {
        int length = 5;
        int breadth = 6;
        int per = 2 * (length + breadth);
        int area = length * breadth;
        System.out.println("perimeter:" + per);
        System.out.println("area:" + area);
    }
}