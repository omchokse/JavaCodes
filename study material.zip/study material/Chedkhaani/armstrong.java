import java.util.Scanner;

public class armstrong {
    public static boolean Armst(int num) {
        double b = 0;
        int r = num;
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while (r > 0) {
            int a = r % 10;
            double d = a;
            double e = n;
            b = b + Math.pow(d, e);
            r = r / 10;
        }
        System.out.println(b);
        if (b == num) {
            System.out.println("true");
            return true;
        } else {
            System.out.println("false");
            return false;
        }
    }

    public static void main(String[] args) {
        Armst(1634);
    }
}