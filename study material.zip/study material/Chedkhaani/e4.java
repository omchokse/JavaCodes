public class e4 {
    public static void main(String[] args) {
        System.out.println("hey");
        int a = 9;
        int b = 6;
        int c = a + b;
        Add(a, b); // calling
        System.out.println(c);
    }

    public static void Add(int a, int b) {
        int c = a + b;
        System.out.println(c);
    }
}
