public class e3 {
    public static void main(String[] args) {
        System.out.println("hey");
        int a = 9;
        int b = 6;
        int c = a + b;
        Add();
        System.out.println(c);
    }

    public static void Add() {
        int a = 11;
        int b = 17;
        int c = a + b;
        Sub();
        System.out.println(c);
    }

    public static void Sub() {
        int a = 11;
        int b = 17;
        int c = a - b;
        System.out.println(c);
    }
}