public class e2 {
    public static void main(String[] args) {
        System.out.println("hey");
        int a = 9;
        int b = 6;
        int c = a + b;
        Add(); // calling
        System.out.println(c);
    }

    public static void Add() {
        int a = 11;
        int b = 17;
        int c = a + b;
        System.out.println(c);
    }
}