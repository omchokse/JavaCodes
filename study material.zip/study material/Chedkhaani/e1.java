public class e1 {
    public static void main(String[] args) {
        System.out.println("hey");
        int a = 9;
        int b = 6;
        int c = a + b;
        System.out.println(c);
    }
}
