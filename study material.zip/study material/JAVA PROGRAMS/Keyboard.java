import java.util.*;

public class Keyboard
{
	public static void main(String [] args)
		{
			System.out.print("Hey! what's your name?");
			Scanner sc=new Scanner(System.in);
			String name=sc.nextLine();
			System.out.println("Welcome "+ name);
		}
}