import java.sql.*;
 
public class jdbcsql
 {
    public static void main(String arg[])
    {
        Connection cn= null;
        try {
            // below two lines are used for connectivity.
            Class.forName("com.mysql.jdbc.Driver");
            cn = DriverManager.getConnection( "jdbc:mysql://localhost:3306/student","root", "12341234");
 
            
            Statement st;
            st = cn.createStatement();
            ResultSet rst;
            rst= st.executeQuery("select * from stu");
            int rollno;
            String name;
            while (rst.next()) 
            {
                rollno = rst.getInt("rollno");
                name = rst.getString("name").trim();
                System.out.println("rollno : " + rollno+ "\t"+ "name : " + name);
            }
            rst.close();
            st.close();
            cn.close();
        }
        catch (Exception exception) {
            System.out.println(exception);
        }
    } // function ends
} // class ends