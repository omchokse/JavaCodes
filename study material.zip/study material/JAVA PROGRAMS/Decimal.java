import java.util.*;
class Decimal
{
    public static void main (String[]args)
    {
        Scanner sc=new Scanner (System.in);
        int num, temp,a,ld,dval=0;
        System.out.println("enter the number to be converted ");
        int b=1;
        sc.temp=nextInt()
        while (temp>0)
        {
            ld=temp;
            temp=temp/10;
            dval=dval+ld;
            b=b*2;
        }
        System.out.println("the converted number is:"+dval);
        
    }
}