import java.util.*;
public class Area
{
	int l,b;
	Scanner sc=new Scanner(System.in);
	public void SetDim()
	{
		l=sc.nextInt();
		b=sc.nextInt();
	}
	public int getArea()
		{
			int area=l*b;
			return area;
		}	
	public static void main(String [] args)
	{
		Area obj1=new Area();
		obj1.SetDim();
		int x =obj1.getArea();
		System.out.println(x);
	}
}