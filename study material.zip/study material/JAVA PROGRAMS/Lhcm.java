import java.util.*;

public class Lhcm
{
	public static void main(String [] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the largest number:");
			int num1=sc.nextInt();
			System.out.println("Enter the smaller number:");
			int num2=sc.nextInt();
			for(int i=num2;i>0;i--)
			{
				if(num1%i==0 && num2%i==0)
				{
					int HCF=(num1*num2)/i;
					System.out.println("HCF: "+i);
					System.out.println("LCM: "+HCF);
					break;
				}
				else
				{
					continue;
				}
			}
		}
}

