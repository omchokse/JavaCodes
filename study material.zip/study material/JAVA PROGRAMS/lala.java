import java.sql.*;

class JDBC
{
    static final String DB_URL = "jdbc:mysql://localhost/mayank";
    static final String USER = "root";
    static final String PASS = "1234sql";
    static final String QUERY = "update student set rollno=13 where Name='Mayank'";
    JDBC() throws ClassNotFoundException
    {
        Class.forName("com.mysql.jdbc.Driver");
    }
    void exec()
    {
        // Open a connection
        try(Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
            PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?)");
        ){
            ps.setInt(1,14);
            ps.setString(2, "John");
            ps.setInt(3,26);
            ps.executeUpdate();
            System.out.println("Row Inserted by Using Prepared Statement");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
public class lala {
    public static void main(String[] args) {
        try {
            JDBC j=new JDBC();
            j.exec();
        }
        catch (ClassNotFoundException e)
        {
            System.out.println("Class Not Found");
        }
    }
}