interface Area
{
    abstract void length();
    abstract void breadth();
    abstract void area();
}
class Rectangle implements Area
{  int a,b;
   public void length()
   {
        a=Integer.parseInt([0]args);
   }
   public void breadth()
   {
     b=Integer.parseInt([1]args);
   }
   public void area()
   {
        System.out.println("The area of rectangle is "+(a*b));
   }
}
    class Square implements Area
{    int a,b;
   public void length()
   {
         a=Integer.parseInt([0]args);
   }
   public void breadth()
   {
     b=Integer.parseInt([1]);
   }
   public void area()
   {
        System.out.println("The area of square is "+(a*b));
   }
}
   class Child
   {
        public static void main(String[]args)
        {
            Rectangle obj1=new Rectangle();
            Square obj2=new Square();
            obj1.length();
            obj1.breadth();
            obj1.area();
        }
   }
