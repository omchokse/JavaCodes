class parent {
    void show(){
        System.out.println("omom");
    }
    
}
class child extends parent{
    void show(){
        System.out.println("om ");
    }
    void display(){
        super.show();
        this.show();
    }

    public static void main(String[] args){
        child c = new child();
        c.display();
        c.show();
    }

}