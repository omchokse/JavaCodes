import java.util.*;

public class Multiply
{
	public static void main(String [] args)
		{
			float a=25.086789f;
			float b=71.779979f;
			float mul=a*b;
			System.out.println(mul);
		}
}