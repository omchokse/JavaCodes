public class GP {
    void area(int s){
        System.out.println(s*s);
    }
    void area(int r){
        System.out.println(3*r*r);
    }
}
class v{
    public static void main(String[] args){
        GP b = new GP();
        int s= 25;
        int r= 34;
        b.area(s);
        b.area(r);

    }
}
