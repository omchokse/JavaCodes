import java.util.*;
public class Main{
	public static void main(String args[])
	{
		int ab=(int)(Math.pow(5,3));
		System.out.println(ab);
	}
 }