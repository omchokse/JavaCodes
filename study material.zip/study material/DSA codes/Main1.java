import java.util.*;

public class Main1 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = 0;
        int a = num;
        int i = 2;
        int rem;
        while (a != 1) {
            if (a % i == 0) {
                sum = sum + i;
                a = a / i;
                i = 2;
            } else {
                i++;
            }
        }
        a = num;
        int sum1 = 0;
        if (a > 10) {
            while (a > 0) {
                rem = a % 10;
                sum1 = sum1 + rem;
                a = a / 10;
            }
        } else {
            sum1 = num;
        }
        if (sum == sum1) {
            System.out.println('1');
        } else {
            System.out.println('0');
        }
    }
}