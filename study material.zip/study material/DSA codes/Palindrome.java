import java.util.*;

public class Palindrome {
    public static class Node {
        char data;
        Node next;

        Node(char data) {
            this.data = data;
            this.next = null;
        }
    }

    public static class Stack {
        static Node head = null;

        static boolean isempty() {
            return head == null;
        }

        static void push(char data) {
            Node newNode = new Node(data);
            if (isempty()) {
                head = newNode;
                return;
            }
            newNode.next = head;
            head = newNode;
        }

        static int pop() {
            if (isempty()) {
                return -1;
            }
            char top = head.data;
            head = head.next;
            return top;
        }

        static int peek() {
            if (isempty()) {
                return -1;
            }
            return head.data;
        }
    }

    public static void main(String[] args) {
        Stack s = new Stack();
        s.push('a');
        s.push('n');
        s.push('n');
        s.push('a');
        for (int i = 4; i > 0; i--) {

        }
    }
}