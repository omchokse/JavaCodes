public class hel {
    public static void main(String[] args) {
        int a = 1 / 10;
        System.out.println(a);
    }
}
