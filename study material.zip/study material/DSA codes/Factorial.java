public class Factorial {
    static int i = 1;
    static int fact = 1;

    static void Fact(int n) {
        if (i == n + 1) {
            System.out.println(fact);
            return;
        }
        fact = fact * i;
        i = i + 1;
        Fact(n);
    }

    public static void main(String[] args) {
        Fact(5);
    }
}