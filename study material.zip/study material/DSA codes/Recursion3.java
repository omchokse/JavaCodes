public class Recursion3 {
    static int fac = 1;

    static void fact(int n) {
        if (n <= 0) {
            System.out.println(fac);
            return;
        }
        fac = n * fac;
        fact(n - 1);
    }

    public static void main(String[] args) {
        fact(5);
    }
}