class Node {
     int data;
     Node right;
     Node left;

     Node(int data) {
          this.data = data;
          right = null;
          left = null;
     }
}

class Tree {
     public static void main(String[] args) {
          Node root = new Node(15);
          Node lef = new Node(10);
          Node righ = new Node(14);
          Node r1 = new Node(12);
          Node r2 = new Node(13);
          root.left = lef;
          lef.right = r1;
          root.right = righ;
          righ.left = r2;
     }

}
