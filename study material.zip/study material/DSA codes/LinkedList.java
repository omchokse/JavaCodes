public class LinkedList {
    static Node head;
    static Node tail;
    static int n = 0;

    public static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
            n++;
        }
    }

    static void AddFirst(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
        }
        newNode.next = head;
        head = newNode;
    }

    static void AddLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
        }
        tail.next = newNode;
        tail = newNode;
    }

    static void RemoveFirst() {
        head = head.next;
        n--;
    }

    static void RemoveLast() {
        Node temp = head;
        for (int i = 0; i < n - 2; i++) {
            temp = temp.next;
        }
        temp.next = null;
        tail = temp;
        n--;
    }

    static void RemoveIndex(int pos) {
        Node temp = head;
        Node tempo;
        for (int i = 0; i < pos - 2; i++) {
            temp = temp.next;
        }
        tempo = temp.next;
        temp.next = tempo.next;
        n--;
    }

    static void Size() {
        System.out.println("size: " + n);
    }

    static void Disp() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    public static void main(String[] args) {
        AddFirst(1);
        AddFirst(2);
        AddFirst(3);
        AddFirst(4);
        AddFirst(5);
        AddLast(6);
        AddLast(7);
        AddLast(8);
        RemoveFirst();
        RemoveLast();
        RemoveIndex(3);
        Size();
        Disp();
    }
}