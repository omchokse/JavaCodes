class StackArray {
    static class Stack {
        static int size;
        static int arr[];
        static int top;

        Stack(int n) {
            arr = new int[n];
            size = n;
            top = -1;
        }

        public static boolean isempty() {
            return top == -1;
        }

        public static void push(int data) {
            if (top == size - 1) {
                System.out.println("stack overflow");
            }
            top = top + 1;
            arr[top] = data;
        }

        public static void pop() {
            if (isempty()) {
                System.out.println("stack underflow");
            }
            top = top - 1;
        }

        static void disp() {
            while (top != -1) {
                System.out.println(arr[top]);
                top = top - 1;
            }
        }
    }

    public static void main(String[] args) {
        Stack s = new Stack(5);
        s.push(1);
        s.push(2);
        s.push(3);
        s.push(4);
        s.push(5);
        s.pop();
        s.pop();
        s.disp();
    }
}