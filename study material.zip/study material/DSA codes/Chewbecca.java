import java.util.*;

public class Chewbecca {

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int a = num;
        int sum = 0;
        int rem;
        while (a > 0) {
            rem = a % 10;
            if (a / 10 == 0 && rem == 9) {
                rem = 9;
            } else {
                if (rem > 4) {
                    rem = 9 - rem;
                    sum = 10 * sum + rem;
                    a = a / 10;
                } else {
                    sum = 10 * sum + rem;
                    a = a / 10;
                }
            }
        }
        int c = sum;
        int sum1 = 0;
        int rem1;
        while (c > 0) {
            rem1 = c % 10;
            sum1 = 10 * sum1 + rem1;
            c = c / 10;
        }
        System.out.println(sum1);
    }
}