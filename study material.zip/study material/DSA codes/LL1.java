class LL1 {
    static int ab = 0;

    public static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
            ab++;
        }
    }

    public static Node head;
    public static Node tail;

    public void AddFirst(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
            return;
        }
        newNode.next = head;
        head = newNode;
    }

    public void AddLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
            return;
        }
        tail.next = newNode;
        tail = newNode;
        newNode.next = null;
    }

    public void AddAfter(int data, int data1) {
        Node temp1 = head;
        while (temp1 != null) {
            if (temp1.data == data) {
                Node newNode = new Node(data1);
                newNode.next = temp1.next;
                temp1.next = newNode;
            }
            temp1 = temp1.next;
        }
    }

    public void AddIndex(int n, int data1) {
        int i = 0;
        Node temp1 = head;
        while (temp1 != null) {
            if (i == n - 1) {
                Node newNode = new Node(data1);
                Node tempo = temp1.next;
                newNode.next = tempo;
                temp1.next = newNode;
            }
            temp1 = temp1.next;
            i = i + 1;
        }
    }

    public void RemoveFirst() { // delete first method
        head = head.next;
        ab--;
    }

    public void RemoveLast() { // delete last method
        Node temp1 = head;
        for (int i = 1; i < ab - 2; i++) {
            temp1 = temp1.next;
        }
        temp1.next = null;
        tail = temp1;
        ab--;
    }

    public void size() {
        System.out.println("Size: " + ab);
    }

    public void Disp() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    public static void main(String[] args) {
        LL1 ll = new LL1();
        ll.AddFirst(1);
        ll.AddFirst(2);
        ll.AddFirst(3);
        ll.AddFirst(4);
        ll.AddFirst(5);
        ll.AddLast(6);
        ll.AddLast(7);
        ll.AddAfter(1, 8);
        ll.AddIndex(3, 9);
        ll.RemoveFirst();
        ll.RemoveLast();
        ll.Disp();
        ll.size();
    }
}