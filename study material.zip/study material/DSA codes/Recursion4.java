import java.util.*;

public class Recursion4 {
    static int i = 0;
    static int j = 0;
    static int k = 1;

    static void Fn(int n) {
        if (i == n - 2) {
            return;
        }
        i = i++;
        int l;
        l = k;
        k = k + j;
        j = l;
        System.out.println(k);
        Fn(n - 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(0);
        System.out.println(1);
        Fn(n);
    }
}
