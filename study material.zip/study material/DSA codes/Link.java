public class Link {

    static class node {
        int data;
        node next;

        node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public static node head;

    static class stack {

        public static void push(int data) {
            node newnode = new node(data);
            if (head == null) {
                head = newnode;
                return;
            }
            newnode.next = head;
            head = newnode;
        }

        public static int pop() {
            if (head == null) {
                return -1;
            }
            int top = head.data;
            head = head.next;
            return top;
        }

        public static int peek() {
            if (head == null) {
                return -1;
            }
            return head.data;
        }
    }

    public static void main(String args[]) {
        stack c = new stack();
        c.push(1);
        c.push(2);
        c.push(3);
        while (head != null) {
            System.out.println(c.peek());
            c.pop();
        }
    }
}