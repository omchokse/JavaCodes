public class Fibonacci {
    static int a = 0;
    static int b = 1;
    static int c;

    static void fibo(int n) {
        if (n == 0) {
            return;
        }
        c = a + b;
        System.out.println(a);
        a = b;
        b = c;
        n = n - 1;
        fibo(n);
    }

    public static void main(String[] args) {
        Fibonacci a = new Fibonacci();
        a.fibo(5);
    }
}