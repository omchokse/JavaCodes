public class Tree3 {
    Tree3 left;
    Tree3 right;
    int label;

    Tree3(int input) {
        label = input;
    }

    public static void search(Tree3 root, int key) {
        if (root == null || root.label == key) {
            System.out.println(root);
        } else if (root.label > key) {
            search(root.left, key);
        } else {
            search(root.right, key);
        }
    }

    public static Tree3 minimumElement(Tree3 root) {
        if (root.left == null)
            return root;
        else {
            return minimumElement(root.left);
        }
    }

    public static void main(String[] args) {
        Tree3 root;
        root = new Tree3(50);
        root.left = new Tree3(20);
        root.right = new Tree3(70);
        root.left.right = new Tree3(10);
        root.left.left = new Tree3(30);
        root.right.left = new Tree3(80);
        root.right.right = new Tree3(60);
        root.left.left = new Tree3(40);
        search(root, 40);
    }
}