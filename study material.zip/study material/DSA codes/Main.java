import java.util.*;

public class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = a;
        int c;
        int sum = 0;
        int rem;
        if (a == 0) {
            System.out.println(5);
        } else if (a >= 1 && a <= 9) {
            System.out.println(a);
        } else {
            while (b > 0) {
                rem = b % 10;
                if (rem == 0) {
                    rem = 5;
                    sum = sum * 10 + rem;
                    b = b / 10;
                } else {
                    sum = sum * 10 + rem;
                    b = b / 10;
                }
            }
            c = sum;
            sum = 0;
            while (c > 0) {
                rem = c % 10;
                sum = sum * 10 + rem;
                c = c / 10;
            }
            System.out.println(sum);
        }
    }
}