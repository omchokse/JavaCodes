
public class hey {

    public static void main(String[] args) {
        int[] arr = { 0, 1, 2, 3, 4, 5, 6, 7 };
        Rotate(arr, 3);
        Display(arr);

    }

    public static void Rotate(int[] brr, int k) {
        for (int l = 0; l < k; l++) {
            int temp = brr[brr.length - 1];
            int a = brr.length - 2;
            while (a >= 0) {
                brr[a + 1] = brr[a];
                a--;
            }
            brr[0] = temp;
        }
    }

    public static void Display(int[] arr) {
        int k = 0;
        while (k < arr.length) {
            System.out.print(arr[k]);
            System.out.print(" ");
            k++;
        }
    }

}
