class Recursion1 {
    static void printNumb(int n) {
        if (n == 0) // base case
        {
            return;
        }
        System.out.println(n);
        printNumb(n - 1); // recursion
    }

    public static void main(String[] args) {
        int n = 5;
        printNumb(n); // calling ek baar toh karni hi padegi na!!
    }
}