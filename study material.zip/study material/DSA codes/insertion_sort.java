public class insertion_sort {
    static boolean rev = false;

    public static void main(String[] args) {
        int arr[] = { 1, 2, 2, 3, 4, 5, 6 };
        duplicate(arr);
    }

    public static void duplicate(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length - 1; j++) {
                if (arr[i] == arr[j]) {
                    rev = true;
                    break;
                }
                break;
            }
        }
        System.out.println(rev);
    }
}