public class Tree1 {
    Tree1 left;
    Tree1 right;
    char labels;

    Tree1(char input) {
        labels = input;
    }
}

class Test {
    public static void main(String[] args) {
        Tree1 root = new Tree1('A');
        root.left = new Tree1('B');
        root.right = new Tree1('C');
        root.left.right = new Tree1('D');
        root.left.left = new Tree1('E');
        inorder(root);
    }

    // inorder = left => root => right
    static void inorder(Tree1 root) {
        if (root == null)
            return;
        inorder(root.left);
        System.out.println(root.labels);
        inorder(root.right);
    }

    // preorder = root =>left => right
    static void preorder(Tree1 root) {
        if (root == null)
            return;
        System.out.println(root.labels);
        preorder(root.left);
        preorder(root.right);
    }

    // postorder = left => right => root
    static void postorder(Tree1 root) {
        if (root == null)
            return;
        postorder(root.left);
        postorder(root.right);
        System.out.println(root.labels);
    }

}
