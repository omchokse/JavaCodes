"use strict"; //treat all JS code as newer version

// alert("hello") // we are using nodejs, not browser

console.log(3 + 3) 
console.log("om")
console.log(8*4)

let  name = "om"
let age = 21
let isLoggedIn = false
let state;

//number => 2 to power 53
//bigint => greater than (2^53)-1
//string => ""
//boolean => true/false
//null => standalone value
//undefined => no value assigned to variable
//symbol => unique

//object

console.log(typeof undefined); //undefined
console.log(typeof null); // object
console.log(typeof "ben"); // string