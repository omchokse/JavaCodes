const accountId = 144553
let accountEmail = "omchokse@gmail.com"
var accountPassword = "12345"
accountCity = "Jaipur"
let accountState;

// accountId = 2 //not allowed

accountEmail ="oc@oc.com"
accountPassword = "21221212"
accountCity = "benaluru"

console.log(accountId);

/*
prefer not to use var
because of issue in blockscope and functional scope
*/

console.table([accountId,accountEmail,accountPassword,accountCity,accountState])