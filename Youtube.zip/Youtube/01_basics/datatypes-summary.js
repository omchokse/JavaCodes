// Primitive

// 7 types: String, Number, Boolean, null, undefined, Symbol, BigInt

const score = 100
const scoreValue = 100.3

const isLoggedIn = false
const outsideTemp = null
let userEmail;

const id = Symbol('123')
const anotherId = Symbol('123')

console.log(id === anotherId)

const bigNumber = 34254532425n

// Referene (Non primitive)

//Array, Objects, Functions

const heroes = ["shaktiman", "nagraj", "doga"]
let myObj={
    name:"om",
    age:21,
    isMarried:false
}

const myfunction = function(){
    console.log("hello");
}

console.log(typeof bigNumber);
console.log(typeof heroes);
console.log(typeof anotherId);


//++++++++++++++++++++++++++++++++

// Stack (Primitive), Heap (Non-Primitive)

let myYoutubename ="omchoksedotcom"

let anothername = myYoutubename
anothername = "chaiaurcode"

console.log(myYoutubename);
console.log(anothername);

let userOne = {
    email: "user@google.com",
    upi: "user@ybl"
}

let userTwo = userOne

userTwo.email = "om@google.com"

console.log(userOne.email)
console.log(userTwo.email)