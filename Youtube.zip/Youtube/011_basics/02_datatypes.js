"use strict"; // treat all JS code as newer version

//alert("hello")  // we are using node js, not browser

console.log(3+3) 

console.log("hello")

let name = "hitesh"
let age = 18
let isLoggedIn = false
let state;
console.log(state);

// number => 2 to power 53
//bigint
//string => ""
//boolean => true/false
//null => standalone value
//undefined => variable is declared but not assigned any value
//symbol => unique and immutable value

//object

console.log(typeof null);