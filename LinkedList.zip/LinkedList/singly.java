class Node {
    int data;
    Node next; 

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
class LinkedList{
    Node head;

    public void insertAtEnd(int data){
        Node newNode = new Node(data);

        if(head == null){
            head = newNode;
            return;
        }
            Node temp = head;
            while(temp.next!=null){
                temp = temp.next;
            }
            temp.next = newNode;
}
    public void insertAtStart(int data){
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void deleteNode(int data){
        if(head == null) return;
        if(head.data == data){
            head = head.next;
            return;
            }
    }

    public void deleteNumberedNode(int num){
        Node temp = head;
        for(int i = num;i>=1;i--){
            temp = temp.next;
        }
        temp.next =temp.next.next;
    }

    
        public void printList(){
            Node temp = head;
            while(temp!=null){
                System.out.print(temp.data + " -> ");
                temp = temp.next;
        }
        System.out.print("null");
    }
}
public class singly{
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);

        list.printList();
    }
}