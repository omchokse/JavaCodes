import java.util.Stack;

public class InBuilt {
    public static void main(String[] args) {
        Stack<Integer> myStack = new Stack<>();
        myStack.push(24);
        myStack.push(48);
        myStack.push(72);
        myStack.push(96);
        System.out.println(myStack.pop());
        System.out.println(myStack.pop());
        System.out.println(myStack.pop());
        System.out.println(myStack.pop());
    }
}