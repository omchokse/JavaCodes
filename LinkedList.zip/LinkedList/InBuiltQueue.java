import java.util.*;
import java.util.LinkedList;

public class InBuiltQueue {
    public static void main(String[] args) {
        Queue<Integer> myQueue = new LinkedList<>();
        myQueue.add(5);
        myQueue.add(10);
        myQueue.add(15);
        myQueue.add(20);
        System.out.println(myQueue.remove());
        System.out.println(myQueue.remove());
    }
}
