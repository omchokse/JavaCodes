public class kth {
    public static void main(String[] args) {
        int value = 87;
        int k = 3;
        System.out.print(kth_value(value, k));
    }

    public static int kth_value(int value, int k) {
        int low = 1;
        int high = value;
        int ans = 0;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (Math.pow(mid, k) <= value) {
                ans = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return ans;
    }
}
