package revision;

public class reverse {
    public static void main(String[] args) {
        int arr[] = { 1, 2, 3, 4, 5, 6 };
        reversefn(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void swapfn(int arr[], int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static void reversefn(int arr[]) {
        int i = 0;
        int j = arr.length - 1;
        while (i < j) {
            swapfn(arr, i, j);
            i++;
            j--;
        }
    }
}
