package revision;

public class binary {
    public static void main(String[] args) {
        int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        System.out.println(bina(arr, 7));
    }

    public static int bina(int arr[], int key) {
        int hi = arr.length - 1;
        int lo = 0;
        while (lo <= hi) {
            int mid = (hi + lo) / 2;
            if (arr[mid] == key) {
                return mid;
            } else if (key > arr[mid]) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return -1;
    }
}
