package revision;

public class rotate_array {
    public static void main(String[] args) {
        int[] arr = { 1, 2, 3, 4, 5, 6, 7 };
        int key = 3;
        rotate(arr, key);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void rotate(int arr[], int key) {
        int n = arr.length;
        key = key % n;
        reverse(arr, 0, n - key - 1);
        reverse(arr, n - key, n - 1);
        reverse(arr, 0, n - 1);
    }

    public static void reverse(int arr[], int i, int j) {
        while (i < j) {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }
    }
}
