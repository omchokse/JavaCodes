package revision;

public class linear_search {
    public static void main(String[] args) {
        int[] arr = { 2, -5, 3, 7, -5, 8, 9 };
        linear(arr, -5);
    }

    public static void linear(int arr[], int k) {
        int flag = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == k) {
                System.out.println(i + " ");
                flag++;
            }
        }
        if (flag == 0) {
            System.out.println("-1");
        }
    }
}
