package revision;

public class rainwater {
    public static void main(String[] args) {
        int[] arr = { 2, 3, 1, 8, 4, 5 };
        rain(arr);
    }

    public static void rain(int arr[]) {
        int n = arr.length;
        int left[] = new int[n];
        int right[] = new int[n];
        left[0] = arr[0];
        for (int i = 1; i < n; i++) {
            left[i] = Math.max(arr[i], left[i - 1]);
        }
        right[n - 1] = arr[n - 1];
        for (int j = n - 2; j >= 0; j--) {
            right[j] = Math.max(right[j + 1], arr[j]);
        }
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += Math.min(left[i], right[i]) - arr[i];
        }
        System.out.println(sum);
    }
}
