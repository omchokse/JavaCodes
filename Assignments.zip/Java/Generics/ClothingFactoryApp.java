//create a pojo class for employee, factory interface and 4 clothing factory class which implements interface ,each factory should have 5 employees,interface has a method list of employees,make 4 functions to display details of employee when search by id ,search by name, search by factory, display all employees.

import java.util.*;

class Employee {
    private int id;
    private String name;
    private String factoryName;

    public Employee(int id, String name, String factoryName) {
        this.id = id;
        this.name = name;
        this.factoryName = factoryName;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFactoryName() {
        return factoryName;
    }

    public String toString() {
        return "Employee { " +
                "ID: " + id +
                ", Name: '" + name + "'" +
                ", Factory: '" + factoryName + "' }";
    }
}

interface ClothingFactory {
    List<Employee> getEmployees();
}

class ShirtFactory implements ClothingFactory {
    private List<Employee> employees = new ArrayList<>();

    public ShirtFactory() {
        employees.add(new Employee(101, "Rohan", "Shirt Factory"));
        employees.add(new Employee(102, "Ron", "Shirt Factory"));
        employees.add(new Employee(103, "Rachel", "Shirt Factory"));
    }

    public List<Employee> getEmployees() {
        return employees;
    }
}

class JeansFactory implements ClothingFactory {
    private List<Employee> employees = new ArrayList<>();

    public JeansFactory() {
        employees.add(new Employee(201, "Mohan", "Jeans Factory"));
        employees.add(new Employee(202, "Mohit", "Jeans Factory"));
        employees.add(new Employee(203, "Mona", "Jeans Factory"));
    }

    public List<Employee> getEmployees() {
        return employees;
    }
}

class ShoesFactory implements ClothingFactory {
    private List<Employee> employees = new ArrayList<>();

    public ShoesFactory() {
        employees.add(new Employee(301, "Aditya", "Shoes Factory"));
        employees.add(new Employee(302, "Aarav", "Shoes Factory"));
        employees.add(new Employee(303, "Archit", "Shoes Factory"));
    }

    public List<Employee> getEmployees() {
        return employees;
    }
}

class JacketFactory implements ClothingFactory {
    private List<Employee> employees = new ArrayList<>();

    public JacketFactory() {
        employees.add(new Employee(401, "Peter", "Jacket Factory"));
        employees.add(new Employee(402, "Patrick", "Jacket Factory"));
        employees.add(new Employee(403, "Pankaj", "Jacket Factory"));
    }

    public List<Employee> getEmployees() {
        return employees;
    }
}

public class ClothingFactoryApp {
    public static void main(String[] args) {
        List<ClothingFactory> factories = List.of(
                new ShirtFactory(),
                new JeansFactory(),
                new ShoesFactory(),
                new JacketFactory());

        searchById(factories, 103);
        searchByName(factories, "Rachel");
        searchByFactory(factories, "Shoes Factory");
        displayAllEmployees(factories);
    }

    public static void searchById(List<ClothingFactory> factories, int id) {
        for (ClothingFactory factory : factories) {
            for (Employee emp : factory.getEmployees()) {
                if (emp.getId() == id) {
                    System.out.println("Found by ID: " + emp);
                    return;
                }
            }
        }
        System.out.println("Employee with ID " + id + " not found.");
    }

    public static void searchByName(List<ClothingFactory> factories, String name) {
        for (ClothingFactory factory : factories) {
            for (Employee emp : factory.getEmployees()) {
                if (emp.getName().equalsIgnoreCase(name)) {
                    System.out.println("Found by Name: " + emp);
                    return;
                }
            }
        }
        System.out.println("Employee with Name '" + name + "' not found.");
    }

    public static void searchByFactory(List<ClothingFactory> factories, String factoryName) {
        boolean found = false;
        System.out.println("Employees in " + factoryName + ":");
        for (ClothingFactory factory : factories) {
            for (Employee emp : factory.getEmployees()) {
                if (emp.getFactoryName().equalsIgnoreCase(factoryName)) {
                    System.out.println(emp);
                    found = true;
                }
            }
        }
        if (!found)
            System.out.println("No employees found in " + factoryName);
    }

    public static void displayAllEmployees(List<ClothingFactory> factories) {
        System.out.println("All Employees:");
        for (ClothingFactory factory : factories) {
            for (Employee emp : factory.getEmployees()) {
                System.out.println(emp);
            }
        }
    }
}
