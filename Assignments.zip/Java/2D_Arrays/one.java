public class one {
    public static void main(String[] args) {
        int[][] arr = new int[3][4]; // [row][column]

    }
}