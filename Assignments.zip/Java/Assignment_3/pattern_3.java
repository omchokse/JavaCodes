package Assignment_3;

import java.util.*;

public class pattern_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int space = 0;
        int star = (2*n)-1;
        int row = 1;
        int j = 1;
        while (j <= space) {
            System.out.print("  ");
            j++;
        }
        while (row <= n) {
            int i = 1;
            while (i <= star) {
                System.out.print(" *");
                i++;
            }
            System.out.println();
            row++;
            star -= 2;
            space += 2;
        }
    }
}