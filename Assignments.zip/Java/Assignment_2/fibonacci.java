package Assignment_2;

import java.util.*;

public class fibonacci {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a = 0;
        int b = 1;
        int c = a + b;
        for (int i = 0; i < n; i++) {
            a = b;
            b = c;
            c = a + b;
        }
        System.out.print(a);
        sc.close();
    }
}