package Assignment_2;

import java.util.*;

public class check_prime {
    static int count = 0;

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                count++;
            }
        }
        if (count < 2) {
            System.out.print("Prime");
        } else {
            System.out.print("Not Prime");
        }
        sc.close();
    }
}