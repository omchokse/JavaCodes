package Assignment_2;

import java.util.*;

public class sum_of_odd_and_even {

    static int even = 0;
    static int odd = 0;
    static int count = 0;

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int m = num;
        while (m > 0) {
            if (count % 2 == 0) {
                even = even + (m % 10);
                m = m / 10;
                count++;
            } else {
                odd = odd + (m % 10);
                m = m / 10;
                count++;
            }
        }
        System.out.println(even);
        System.out.println(odd);
        sc.close();
    }
}