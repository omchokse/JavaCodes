package Assignment_2;

import java.util.*;

public class reverse {
    static int sum = 0;
    static int fac = 1;

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int n = num;
        while (n > 0) {
            sum = sum * 10 + fac * (n % 10);
            n = n / 10;
        }
        sc.close();
        System.out.print(sum);
    }
}