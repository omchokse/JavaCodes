package Assignment_2;

import java.util.*;

public class LCM {
    static int j = 0;

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        for (int i = 1; i < m * n; i++) {
            if (i % m == 0 && i % n == 0) {
                j = i;
                break;
            }
        }
        sc.close();
        System.out.print(j);
    }
}
