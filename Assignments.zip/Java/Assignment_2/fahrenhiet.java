package Assignment_2;

import java.util.*;

public class fahrenhiet {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int low = sc.nextInt();
        int max = sc.nextInt();
        int step = sc.nextInt();
        for (int i = low; i <= max; i = i + step) {
            int c = (i - 32);
            int d = (5 * c) / 9;
            System.out.println(i + " " + d);
        }
        sc.close();
    }
}