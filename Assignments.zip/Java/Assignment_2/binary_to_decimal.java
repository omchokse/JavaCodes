package Assignment_2;

import java.util.*;

public class binary_to_decimal {
    static double count = 0;
    static double sum = 0;

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int n = num;
        while (n > 0) {
            sum = sum + n % 10 * (Math.pow(2, count));
            n = n / 10;
            count++;
        }
        System.out.print((int) sum);
        sc.close();
    }
}