package Assignment_2;

import java.util.*;

public class count_digits {
    static int count = 0;

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int k = sc.nextInt();
        int l = num;
        while (l > 0) {
            if (l % 10 == k) {
                count++;
            }
            l = l / 10;
        }
        System.out.println(count);
        sc.close();
    }
}