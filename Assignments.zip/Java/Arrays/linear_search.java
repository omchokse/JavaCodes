public class linear_search {
    public static void main(String[] args) {
        int[] arr = { 2, 3, 4, 5, -4, 7, 11 };
        int target = 4;
        System.out.println(Search(arr, target));
    }

    public static int Search(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target)
                return i;
        }
        return -1;
    }
}
