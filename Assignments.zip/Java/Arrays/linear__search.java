public class linear__search {
    public static void main(String[] args) {
        int[] arr = { 4, 5, 6, 7, 8, 9 };
        int key = 7;
        lSearch(arr, key);
    }

    public static void lSearch(int arr[], int key) {
        int flag = -1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                flag = i;
            }
        }
        System.out.println(flag);
    }
}