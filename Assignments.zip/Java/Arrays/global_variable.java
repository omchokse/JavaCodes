public class global_variable {
    public static void main(String[] args) {
        System.out.println("hey");
        int x = 60;
        System.out.println(val);
        fun(x);
        System.out.println(val);
    }

    static int val = 100; // sabse pehle static block chalta hai

    public static void fun(int x) {
        int a = 90;
        System.out.println(a);
        val = 120;
        System.out.println(val);
        System.out.println(global_variable.val);
    }
}
