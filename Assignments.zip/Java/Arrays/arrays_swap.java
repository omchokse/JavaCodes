public class arrays_swap {
    public static void main(String[] args) {
        int[] arr = { 1, 2, 3, 4, 5 };
        System.out.println(arr[0] + " " + arr[4]);
        Swap(arr, 0, 4); // (5, 2, 3, 4, 1) => arr
        System.out.println(arr[0] + " " + arr[4]);
    }

    public static void Swap(int arr[], int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

// reverse
// 5/2 = 2
// arr = (1,2,3,4,5) => (5,4,3,2,1)

// for(int i=0;i<=arr.length/2;i++){
// Swap(arr[],i,arr.length-i-1) // 5-0-1=4