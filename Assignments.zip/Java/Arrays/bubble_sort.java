public class bubble_sort {
    public static void main(String[] args) {
        int[] arr = { 12, 5, 7, 13, 19 };
        bubblesort(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void bubblesort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < arr.length; i++) { // passes
            for (int j = 0; j < n - i; j++) { // comparing and swapping
                if (arr[j + 1] < arr[j]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}
