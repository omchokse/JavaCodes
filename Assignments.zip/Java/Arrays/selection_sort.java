public class selection_sort {
    public static void main(String[] args) {
        int[] arr = { 64, 25, 12, 22, 11 };
        selectionSort(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void selectionSort(int[] arr) {
        for (int turn = 0; turn < arr.length; turn++) {
            int min = turn;
            for (int i = turn + 1; i < arr.length; i++) {

                if (arr[i] < arr[min]) {
                    min = i;
                }

            }
            int temp = arr[turn];
            arr[turn] = arr[min];
            arr[min] = temp;
        }
    }
}