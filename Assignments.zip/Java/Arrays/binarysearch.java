public class binarysearch {
    /*
     * binary search => * jab array sorted ho tab lagegi
     * public static void Main(String [] args){
     * int arr[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
     * int target = 10;
     * bsearch(arr,target);
     * }
     * public static int bsearch(int arr[], int target){ // target = 10
     * int n = arr.length; //15
     * int lo = 0;
     * int hi = n-1;
     * while(lo<=hi){
     * --> int mid = (hi+lo)/2; => 14+0/2 = 7
     * if(arr[mid]==target){
     * return mid;
     * }
     * else if(arr[mid]<target){ // 8<10
     * lo = mid + 1; //lo = 8 hi = 14 mid = 22/2 = 11 arr[11] = 12;
     * }
     * else{
     * hi = mid-1; //lo = 8 hi = 11-1= 10 mid = 18/2 = 9
     * }
     * }
     * return -1;
     * }
     * 
     */
}
